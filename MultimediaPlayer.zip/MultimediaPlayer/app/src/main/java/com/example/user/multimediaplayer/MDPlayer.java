package com.example.user.multimediaplayer;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;

import java.io.File;
import java.time.Instant;
import java.util.ArrayList;

public class MDPlayer extends AppCompatActivity implements View.OnClickListener{
    static MediaPlayer np;
    ArrayList<File> cns;
    Thread actseekbar;
    int posicion;
    Uri uri;

    ImageButton btnpy,btnfw,btnbw,btnbck;
    SeekBar sb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mdplayer);
        btnpy =(ImageButton)findViewById(R.id.btnimgPlay);
        btnfw =(ImageButton)findViewById(R.id.btnimgForward);
        btnbw = (ImageButton)findViewById(R.id.btnimgBackWard);
        btnbck = (ImageButton)findViewById(R.id.btnback);
        sb = (SeekBar) findViewById(R.id.skBr);

        btnpy.setOnClickListener(this);
        btnfw.setOnClickListener(this);
        btnbw.setOnClickListener(this);
        btnbck.setOnClickListener(this);
        sb.setOnClickListener(this);

        actseekbar = new Thread(){
            @Override
            public void run() {
                super.run();
                int trtime = np.getDuration();
                sb.setMax(trtime);
                int posact = 0;
                int ejec = 0 ;
                boolean bool = false;
                while (posact < trtime){
                    try {
                        sleep(500);
                        posact =np.getCurrentPosition();
                        sb.setProgress(posact);
                    } catch (Exception e){

                    }
                }
            }
        };
        if (np!= null){
            np.stop();
        }try {
            Intent i = getIntent();
            Bundle b = i.getExtras();
            cns=(ArrayList)b.getParcelableArrayList("songs");
            posicion = (int) b.getInt("pos", 0);
            uri = Uri.parse(cns.get(posicion).toString());
            np = MediaPlayer.create(getApplication(),uri);
            actseekbar.start();
            np.start();
        }catch (Exception e){
        }
    }

    @Override
    public void onClick(View view) {

    }
}
